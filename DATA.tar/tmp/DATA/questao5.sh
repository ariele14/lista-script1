#! /bin/bash

mkdir  /tmp/Data
echo "A data do sistema: $(date +'%F %R') " > /tmp/DATA/DATA.txt
cp ./*  /tmp/DATA
