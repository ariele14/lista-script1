#! /bin/bash

read  -p  "Digite aqui:" diretorio1 diretorio2

ls ${diretorio1}  ${diretorio2}
